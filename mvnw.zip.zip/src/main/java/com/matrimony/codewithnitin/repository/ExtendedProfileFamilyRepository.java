package com.matrimony.codewithnitin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.matrimony.codewithnitin.entity.ExtendedProfileFamily;

public interface ExtendedProfileFamilyRepository extends JpaRepository<ExtendedProfileFamily, Integer>{

}
