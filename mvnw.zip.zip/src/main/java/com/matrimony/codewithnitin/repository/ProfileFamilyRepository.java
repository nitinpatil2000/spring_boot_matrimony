package com.matrimony.codewithnitin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.matrimony.codewithnitin.entity.ProfileFamily;

public interface ProfileFamilyRepository extends JpaRepository<ProfileFamily, Integer> {

}
