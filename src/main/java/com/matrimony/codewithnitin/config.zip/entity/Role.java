package com.matrimony.codewithnitin.entity;

public enum Role {

	  USER,
	  ADMIN
	}

