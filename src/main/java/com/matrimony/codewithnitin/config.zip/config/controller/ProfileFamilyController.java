package com.matrimony.codewithnitin.config.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.matrimony.codewithnitin.entity.ProfileFamily;
import com.matrimony.codewithnitin.payload.ApiResponce;
import com.matrimony.codewithnitin.repository.ProfileFamilyRepository;
import com.matrimony.codewithnitin.service.ProfileFamilyService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ProfileFamilyController {

	
	@Autowired
	ProfileFamilyRepository profileFamilyRepository;
	
	@Autowired
	ProfileFamilyService profileFamilyService;

	

	@PostMapping("/createprofilefamily")
	public ProfileFamily create(@RequestBody ProfileFamily profilFamily) {
		return profileFamilyRepository.save(profilFamily);
	}

	
	@GetMapping("/profilefamily")
	public List<ProfileFamily> getData() {
		return profileFamilyService.getData();
	}
	
	
	
	@GetMapping("/profilefamily/{profileFamilyId}")
	public ResponseEntity<ProfileFamily> getSingleProfileFamily(@PathVariable Integer profileFamilyId){
		ProfileFamily profileFamily = this.profileFamilyService.getSingleProfileFamily(profileFamilyId);
		return new ResponseEntity<ProfileFamily>(profileFamily, HttpStatus.OK);
	}
	
	
	
	
	@PutMapping("/profilefamily")
	public ProfileFamily update(@RequestBody ProfileFamily profileFamily) {
		ProfileFamily save = profileFamilyRepository.save(profileFamily);
		return save;
	}
	
	@DeleteMapping("/profilefamily/{profileFamilyId}")
	public ResponseEntity<ApiResponce> deleteProfileDetails(@PathVariable("profileFamilyId") Integer profileFamilyId)
	{
	this.profileFamilyService.deleteProfileFamily(profileFamilyId);
	return new ResponseEntity<ApiResponce>(new ApiResponce("User Deleted Successfully", true,100), HttpStatus.OK);
	}
}
